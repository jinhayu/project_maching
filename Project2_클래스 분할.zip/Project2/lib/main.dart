import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_options.dart';

// 분리된 화면 import
import 'login.dart';
import 'sign.dart';
import 'profile.dart';

// Firebase 초기화
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const WebLayoutApp());
}

class WebLayoutApp extends StatelessWidget {
  const WebLayoutApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(scaffoldBackgroundColor: const Color(0xFFF8F9FA)),
      routes: {
        '/login': (context) => const LoginScreen(),
        '/sign': (context) => const RegistrationScreen(),
        '/profile': (context) => const ProfilePage(), // ✅ 추가
      },
      home: const Scaffold(
        body: SafeArea(child: AuthGate()),
      ),
    );
  }
}

// ✅ 로그인 상태를 감시해서 user 전달만 (페이지는 고정)
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        final user = snapshot.data;
        return MainPage(user: user);
      },
    );
  }
}

// ✅ 메인 페이지 (왼쪽/중앙/오른쪽 3열 구성)
class MainPage extends StatelessWidget {
  final User? user;
  const MainPage({super.key, this.user});

  @override
  Widget build(BuildContext context) {
    final isLoggedIn = user != null;
    final displayName = user?.displayName?.trim();
    final email = user?.email?.trim();
    final initial = (displayName?.isNotEmpty == true
        ? displayName![0]
        : (email?.isNotEmpty == true ? email![0] : 'U'))
        .toUpperCase();

    return Column(
      children: [
        // 상단 네비게이션
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
          decoration: const BoxDecoration(
            color: Colors.white,
            boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4)],
          ),
          child: Row(
            children: [
              const Text(
                "Synergy",
                style: TextStyle(
                    fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black87),
              ),
              const Spacer(),
              if (!isLoggedIn) ...[
                TextButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                  ),
                  child: const Text('로그인', style: TextStyle(fontSize: 15)),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF4D4D),
                    foregroundColor: Colors.white,
                    shape:
                    RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const RegistrationScreen()),
                  ),
                  child: const Text('회원가입'),
                ),
              ] else ...[
                Row(
                  children: [
                    CircleAvatar(
                      radius: 16,
                      backgroundColor: const Color(0xFFE0E0E0),
                      child:
                      Text(initial, style: const TextStyle(color: Colors.white)),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      displayName?.isNotEmpty == true
                          ? '$displayName님'
                          : (email ?? ''),
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(width: 8),
                    TextButton(
                      onPressed: () async => await FirebaseAuth.instance.signOut(),
                      child: const Text('로그아웃'),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),

        // 본문 3열
        Expanded(child: ResponsiveBody(user: user)),
      ],
    );
  }
}

// --------------------------------------
// 반응형 본문
// --------------------------------------
class ResponsiveBody extends StatelessWidget {
  final User? user;
  const ResponsiveBody({super.key, this.user});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;

    const small = 900.0;
    const medium = 1200.0;

    final horizontalPad = w >= 1600
        ? 180.0
        : w >= 1400
        ? 140.0
        : w >= 1200
        ? 100.0
        : w >= 900
        ? 48.0
        : 16.0;

    return LayoutBuilder(builder: (context, constraints) {
      final width = constraints.maxWidth;

      // 1열 (모바일)
      if (width < small) {
        return SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: horizontalPad, vertical: 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              LeftPanel(user: user),
              const SizedBox(height: 16),
              const CenterPanel(),
              const SizedBox(height: 16),
              const RightPanel(),
            ],
          ),
        );
      }

      // 2열 (중간 폭)
      if (width < medium) {
        return SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: horizontalPad, vertical: 24),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(flex: 3, child: LeftPanel(user: user)),
              const SizedBox(width: 16),
              const Expanded(flex: 5, child: CenterPanel()),
            ],
          ),
        );
      }

      // 3열 (넓은 화면)
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: horizontalPad, vertical: 24),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(flex: 2, child: LeftPanel(user: user)),
            const SizedBox(width: 24),
            const Expanded(flex: 5, child: CenterPanel()),
            const SizedBox(width: 24),
            const Expanded(flex: 3, child: RightPanel()),
          ],
        ),
      );
    });
  }
}

// --------------------------------------
// LeftPanel - 로그인 상태 반영
// --------------------------------------
class LeftPanel extends StatelessWidget {
  final User? user;
  const LeftPanel({super.key, this.user});

  @override
  Widget build(BuildContext context) {
    final isLoggedIn = user != null;
    final name = user?.displayName?.trim();
    final email = user?.email?.trim();

    if (isLoggedIn) {
      return Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: Colors.grey[300]!),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const CircleAvatar(
                radius: 24,
                backgroundColor: Color(0xFFE0E0E0),
                child: Icon(Icons.person, size: 30, color: Colors.white),
              ),
              const SizedBox(height: 16),
              Text(
                name?.isNotEmpty == true ? '$name 님, 환영합니다!' : '환영합니다!',
                style:
                const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              if (email != null)
                Text(email,
                    style:
                    TextStyle(fontSize: 13, color: Colors.grey[700])),
              const SizedBox(height: 16),
              const Divider(),
              const Text('내 활동',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              _menu(Icons.folder_copy_outlined, '내 프로젝트 보기'),
              _menu(Icons.favorite_border, '관심 프로젝트'),
              _menu(Icons.settings_outlined, '프로필 설정'),
            ],
          ),
        ),
      );
    }

    // 미로그인 상태
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.grey[300]!),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const CircleAvatar(
              radius: 24,
              backgroundColor: Color(0xFFE0E0E0),
              child: Icon(Icons.person, size: 30, color: Colors.white),
            ),
            const SizedBox(height: 16),
            const Text('로그인 해주세요.',
                style:
                TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Row(
              children: [
                const Text('지금 참여가능한 이벤트'),
                const SizedBox(width: 4),
                Icon(Icons.link, size: 16, color: Colors.grey[600]),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                children: [
                  Icon(Icons.rocket_launch, color: Colors.white),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '100일동안 개발일지 쓰고\n3만원에 판 돌려받으세요',
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _menu(IconData icon, String label) {
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, size: 20),
      title: Text(label, style: const TextStyle(fontSize: 14)),
      onTap: () {},
    );
  }
}

// --------------------------------------
// CenterPanel & RightPanel 복구
// --------------------------------------
class CenterPanel extends StatelessWidget {
  const CenterPanel({super.key});
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Text('🔗 Connect, Make, Launch.',
            style: TextStyle(fontSize: 16, color: Colors.grey)),
        const SizedBox(height: 16),
        const Text(
          '당신의 프로젝트를\n시너지에서 펼치세요!',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Text(
          '당신의 아이디어로 팀을 만들고, 아이디어를 공유하고,\n사람들과 연결하며 함께 성장하세요.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 16, color: Colors.grey[700]),
        ),
      ],
    );
  }
}

class RightPanel extends StatelessWidget {
  const RightPanel({super.key});
  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('오른쪽 패널 영역', style: TextStyle(color: Colors.grey)),
    );
  }
}
