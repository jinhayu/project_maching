import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// 회원가입 화면 (이메일 인증 후 자동 로그인 + 프로필 이동)
class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _studentIdController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  final List<String> _departments = [
    '학과를 선택하세요', '컴퓨터공학과', '경영학과', '전자공학과', '디자인학과',
    '기계공학과', '화학공학과', '생명과학과'
  ];
  String? _selectedDepartment = '학과를 선택하세요';

  bool _isLoading = false;
  bool _verificationSent = false;
  bool _emailVerified = false;
  bool _isSendingVerify = false;
  bool _isCheckingVerify = false;

  bool _isValidEmail(String v) {
    final s = v.trim();
    final re = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
    return re.hasMatch(s);
  }

  // ① 계정 생성 & 인증 메일 발송
  Future<void> _createAccountAndSendVerify() async {
    if (!mounted) return;

    if (_nameController.text.trim().isEmpty ||
        _studentIdController.text.trim().isEmpty ||
        _selectedDepartment == '학과를 선택하세요' ||
        _passwordController.text.isEmpty ||
        _confirmPasswordController.text.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('모든 필드를 입력해 주세요.')));
      return;
    }
    if (_passwordController.text != _confirmPasswordController.text) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('비밀번호가 일치하지 않습니다.')));
      return;
    }
    if (!_isValidEmail(_emailController.text)) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('올바른 이메일 형식을 입력해 주세요.')));
      return;
    }

    setState(() => _isSendingVerify = true);
    try {
      final credential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      final user = credential.user;
      await user?.updateDisplayName(_nameController.text.trim());
      await user?.sendEmailVerification();

      setState(() => _verificationSent = true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('인증 메일을 전송했습니다. 메일함을 확인해 주세요.'),
        ),
      );
    } on FirebaseAuthException catch (e) {
      final msg = switch (e.code) {
        'weak-password' => '비밀번호는 6자 이상이어야 합니다.',
        'email-already-in-use' => '이미 사용 중인 이메일입니다.',
        'invalid-email' => '유효하지 않은 이메일 형식입니다.',
        _ => '회원가입 실패: ${e.message ?? e.code}',
      };
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    } finally {
      setState(() => _isSendingVerify = false);
    }
  }

  // ② 이메일 인증 확인 + 자동 로그인
  Future<void> _checkEmailVerified() async {
    setState(() => _isCheckingVerify = true);
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('먼저 계정을 생성해 주세요.')));
        return;
      }

      await user.reload();
      final refreshed = FirebaseAuth.instance.currentUser;
      final verified = refreshed?.emailVerified ?? false;
      setState(() => _emailVerified = verified);

      if (verified) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('✅ 이메일 인증이 완료되었습니다.')),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('❌ 아직 인증이 완료되지 않았습니다. 메일의 링크를 클릭해 주세요.'),
          ),
        );
      }
    } finally {
      setState(() => _isCheckingVerify = false);
    }
  }


  // ③ 수동 회원가입 완료 (예비용, 인증 없이 눌렀을 때)
  Future<void> _finishRegistration() async {
    if (!_emailVerified) return;
    setState(() => _isLoading = true);
    try {
      if (!mounted) return;
      Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _onEmailChanged(String _) {
    if (_verificationSent || _emailVerified) {
      setState(() {
        _verificationSent = false;
        _emailVerified = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text('회원가입'),
        backgroundColor: Colors.white,
        elevation: 1,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: SizedBox(
            width: 500,
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16.0),
              ),
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(32.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('회원가입',
                        style: TextStyle(
                            fontSize: 24, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 32),

                    _buildTextField('이름', '이름을 입력하세요',
                        controller: _nameController),
                    const SizedBox(height: 16),
                    _buildTextField('학번', '학번을 입력하세요',
                        controller: _studentIdController),
                    const SizedBox(height: 16),
                    _buildDepartmentDropdown(),
                    const SizedBox(height: 16),
                    _buildTextField('비밀번호', '비밀번호 (6자 이상)',
                        obscureText: true, controller: _passwordController),
                    const SizedBox(height: 16),
                    _buildTextField('비밀번호 확인', '비밀번호를 다시 입력하세요',
                        obscureText: true,
                        controller: _confirmPasswordController),
                    const SizedBox(height: 16),
                    _buildEmailFieldWithVerifyButtons(),
                    const SizedBox(height: 32),

                    // ✅ 이메일 인증 후 회원가입 완료 버튼
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFFF4D4D),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 16.0),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.0)),
                        ),
                        onPressed: (!_emailVerified || _isLoading)
                            ? null
                            : _finishRegistration,
                        child: _isLoading
                            ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 3,
                          ),
                        )
                            : const Text(
                          '회원가입 완료',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ---------------- UI 하위 위젯 ----------------
  Widget _buildTextField(String label, String hintText,
      {bool obscureText = false, TextEditingController? controller}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          obscureText: obscureText,
          decoration: InputDecoration(
            hintText: hintText,
            border: const OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(8.0))),
            enabledBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(8.0)),
              borderSide: BorderSide(color: Colors.grey),
            ),
            focusedBorder: const OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(8.0)),
              borderSide:
              BorderSide(color: Color(0xFFFF4D4D), width: 2),
            ),
            contentPadding: const EdgeInsets.symmetric(
                horizontal: 16.0, vertical: 12.0),
          ),
        ),
      ],
    );
  }

  Widget _buildDepartmentDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('학과', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          ///value: _selectedDepartment,
          decoration: const InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.all(Radius.circular(8.0)),
            ),
            contentPadding:
            EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
          ),
          items: _departments
              .map((d) => DropdownMenuItem<String>(
            value: d,
            child: Text(d),
          ))
              .toList(),
          onChanged: (v) => setState(() => _selectedDepartment = v),
        ),
      ],
    );
  }

  Widget _buildEmailFieldWithVerifyButtons() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('이메일', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                onChanged: _onEmailChanged,
                decoration: const InputDecoration(
                  hintText: '이메일을 입력하세요',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(8.0)),
                  ),
                  contentPadding:
                  EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                ),
              ),
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              onPressed:
              _isSendingVerify ? null : _createAccountAndSendVerify,
              child: _isSendingVerify
                  ? const SizedBox(
                  height: 18,
                  width: 18,
                  child: CircularProgressIndicator(strokeWidth: 2))
                  : Text(_verificationSent ? '재전송' : '인증 메일'),
            ),
            const SizedBox(width: 8),
            OutlinedButton(
              onPressed: _isCheckingVerify ? null : _checkEmailVerified,
              child: _isCheckingVerify
                  ? const SizedBox(
                  height: 18,
                  width: 18,
                  child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('인증 확인'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        if (_verificationSent && !_emailVerified)
          const Text(
            '메일의 인증 링크 클릭 후 "인증 확인"을 눌러주세요.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        if (_emailVerified)
          const Text(
            '이메일 인증 완료 ✔',
            style: TextStyle(fontSize: 12, color: Colors.green),
          ),
      ],
    );
  }
}
