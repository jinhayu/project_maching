import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text('내 프로필'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.pushReplacementNamed(context, '/login');
            },
          ),
        ],
      ),
      body: Center(
        child: user == null
            ? const Text('로그인 정보 없음')
            : Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('이메일: ${user.email}'),
            const SizedBox(height: 10),
            Text('UID: ${user.uid}'),
          ],
        ),
      ),
    );
  }
}
